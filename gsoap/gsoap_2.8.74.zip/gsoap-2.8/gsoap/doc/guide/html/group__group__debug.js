var group__group__debug =
[
    [ "DEBUG", "group__group__debug.html#gad72dbcf6d0153db1b8d8a58001feed83", null ],
    [ "DEBUG_STAMP", "group__group__debug.html#ga245426f6e253f0d00529a2b72447b956", null ],
    [ "SOAP_DEBUG", "group__group__debug.html#gafb8f9e482dad215431176d379369344c", null ],
    [ "SOAP_MEM_DEBUG", "group__group__debug.html#gab9e34ba8fb127ddf35b3d66bd14fc683", null ],
    [ "logging", "group__group__debug.html#gac637945d0869d91a4b00dc1ddaced537", null ],
    [ "soap_logging_stats", "group__group__debug.html#ga628bfc4b7a6ba4bef23bea4787ef5f5d", null ],
    [ "soap_reset_logging_stats", "group__group__debug.html#ga4965a2d58aec4ae3983ae73fc711df60", null ],
    [ "soap_set_logging_inbound", "group__group__debug.html#gaa04b3b63c8ba47da5673fbafe385e9ad", null ],
    [ "soap_set_logging_outbound", "group__group__debug.html#ga08a67e8989dc849602b61e438a7f86e2", null ],
    [ "soap_set_recv_logfile", "group__group__debug.html#ga3cc1cddba7dcbc38cdb1bc66c4e08fec", null ],
    [ "soap_set_sent_logfile", "group__group__debug.html#ga95729c28f712cf4bca312595b5ce2687", null ],
    [ "soap_set_test_logfile", "group__group__debug.html#ga409ebe1fb5f1044a20ad12b382068148", null ]
];