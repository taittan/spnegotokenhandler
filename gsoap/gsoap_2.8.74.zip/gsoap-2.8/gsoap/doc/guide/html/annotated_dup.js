var annotated_dup =
[
    [ "_xop__Include", "struct__xop_____include.html", "struct__xop_____include" ],
    [ "Namespace", "struct_namespace.html", "struct_namespace" ],
    [ "soap", "structsoap.html", "structsoap" ],
    [ "soap_cookie", "structsoap__cookie.html", "structsoap__cookie" ],
    [ "soap_dime", "structsoap__dime.html", "structsoap__dime" ],
    [ "SOAP_ENV__Code", "struct_s_o_a_p___e_n_v_____code.html", "struct_s_o_a_p___e_n_v_____code" ],
    [ "SOAP_ENV__Detail", "struct_s_o_a_p___e_n_v_____detail.html", "struct_s_o_a_p___e_n_v_____detail" ],
    [ "SOAP_ENV__Fault", "struct_s_o_a_p___e_n_v_____fault.html", "struct_s_o_a_p___e_n_v_____fault" ],
    [ "SOAP_ENV__Header", "struct_s_o_a_p___e_n_v_____header.html", null ],
    [ "SOAP_ENV__Reason", "struct_s_o_a_p___e_n_v_____reason.html", "struct_s_o_a_p___e_n_v_____reason" ],
    [ "soap_mime", "structsoap__mime.html", "structsoap__mime" ],
    [ "soap_multipart", "structsoap__multipart.html", "structsoap__multipart" ],
    [ "xsd__base64Binary", "structxsd____base64_binary.html", "structxsd____base64_binary" ],
    [ "xsd__hexBinary", "structxsd____hex_binary.html", "structxsd____hex_binary" ]
];