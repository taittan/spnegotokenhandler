var annotated_dup =
[
    [ "std", "namespacestd.html", "namespacestd" ],
    [ "_a__address_book", "class__a____address__book.html", "class__a____address__book" ],
    [ "a__address", "classa____address.html", "classa____address" ],
    [ "g", "classg.html", "classg" ]
];