var group__group__dime =
[
    [ "xsd__base64Binary", "structxsd____base64_binary.html", [
      [ "__ptr", "structxsd____base64_binary.html#a6ba9f9e291b2b26e0696bd48f4e983be", null ],
      [ "__size", "structxsd____base64_binary.html#aa2dfd4d99f8280c413b9ff25a69a8729", null ],
      [ "id", "structxsd____base64_binary.html#a6398e9d86079896facc3005871d7fe27", null ],
      [ "options", "structxsd____base64_binary.html#a16d2bb03d68bf276bad5fd7cccd55bbe", null ],
      [ "type", "structxsd____base64_binary.html#acbc2d7ba24334ccc4f8ec36e9122e9e5", null ]
    ] ],
    [ "_xop__Include", "struct__xop_____include.html", [
      [ "__ptr", "struct__xop_____include.html#ab4388e79bc98595fefbde2fbcf5489ba", null ],
      [ "__size", "struct__xop_____include.html#a92be7a45ca282feee3a53fedf5c3a405", null ],
      [ "id", "struct__xop_____include.html#a378e555a35df041c14d0f767dd128c20", null ],
      [ "options", "struct__xop_____include.html#a894a54df2d052989ff2c20d344f56c91", null ],
      [ "type", "struct__xop_____include.html#a0d70af0d2c123766ce188cf2dd15833a", null ]
    ] ],
    [ "xsd__hexBinary", "structxsd____hex_binary.html", [
      [ "__ptr", "structxsd____hex_binary.html#adade1cbcc8c6ff25037794f38944f999", null ],
      [ "__size", "structxsd____hex_binary.html#a4c213d448af3955f37dded4f238301e6", null ],
      [ "id", "structxsd____hex_binary.html#ac5587513560c554d1a4e79c12cf539b3", null ],
      [ "options", "structxsd____hex_binary.html#ac48a47543612c0ef7d82d9c56e8ef0ea", null ],
      [ "type", "structxsd____hex_binary.html#aca3989c246550b6281ba8ee5863ac75e", null ]
    ] ],
    [ "soap_dime", "structsoap__dime.html", [
      [ "begin", "structsoap__dime.html#a4fe0d524cff9e2e467487dba18dd61f8", null ],
      [ "end", "structsoap__dime.html#af4c0808ed995d085514cfc0962bb4565", null ],
      [ "list", "structsoap__dime.html#a478a23b3994a35d1c0945751106cb4f6", null ]
    ] ],
    [ "soap_clr_dime", "group__group__dime.html#ga7f319170ba950c4b4025c5c1739a26fc", null ],
    [ "soap_dime_option", "group__group__dime.html#ga4829f833abe74febcb8e5fe9360ab591", null ],
    [ "soap_set_dime", "group__group__dime.html#ga466502a32af0672d589e919a7c882a57", null ],
    [ "soap_set_dime_attachment", "group__group__dime.html#ga742f96848174e27bfc8df7425b870f4b", null ]
];